package com.nad.reader;

public class DataReaderFactory {

	public static DataReader getDataReader(String type) {
		DataReader datareader=null;
		switch (type) {
		case "csv":
			datareader=new CsvDataReader();
			break;
		case "xlsx":
			datareader=new ExcelDataReader();
			break;

		default:
			break;
		}
		return datareader;
	}
}
