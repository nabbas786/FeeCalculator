package com.nad.reader;

import java.io.BufferedReader;
import java.io.IOException;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import com.nad.model.TransactionDetails;

public class CsvDataReader implements DataReader{

	@Override
	public List<TransactionDetails> readData(String filePath) throws IOException, ParseException {
		Path path=Paths.get(filePath);
		List<TransactionDetails> transactionDetails=new ArrayList<TransactionDetails>();
		try(BufferedReader br=Files.newBufferedReader(path)){
			String nextLine=br.readLine();
			nextLine=br.readLine();
			while(nextLine !=null) {
				
				String [] attributes=nextLine.split(",");
				transactionDetails.add(createTransaction(attributes));
				nextLine=br.readLine();
			}
		}catch (IOException e) {
			throw e;
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}
		return transactionDetails;
	}
	private TransactionDetails createTransaction(String [] attributes) throws ParseException {
		TransactionDetails tx=new TransactionDetails();
		tx.setExtTranasactionId(attributes[0]);
		tx.setClientId(attributes[1]);
		tx.setSecurityId(attributes[2]);
		tx.setTransactionType(attributes[3]);
		SimpleDateFormat formatter = new SimpleDateFormat("MM/DD/YYYY", Locale.ENGLISH);
		 
		String dateInString = attributes[4];
		Date date = formatter.parse(dateInString);
		tx.setTransactionDate(date);
		tx.setMarketValue(Double.valueOf(attributes[5]));
		tx.setPriority(attributes[6]);
		return tx;
	}
	
}
