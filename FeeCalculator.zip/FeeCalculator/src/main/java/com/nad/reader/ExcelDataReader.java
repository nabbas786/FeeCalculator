package com.nad.reader;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.nad.model.TransactionDetails;

public class ExcelDataReader implements DataReader{

	@Override
	public List<TransactionDetails> readData(String filePath) throws IOException {
		List<TransactionDetails> transactions=new ArrayList<>();
		try (FileInputStream input = new FileInputStream(new File(filePath));
				XSSFWorkbook workBook = new XSSFWorkbook(input);) {
			XSSFSheet sheet = workBook.getSheetAt(0);
			int totalRows=sheet.getLastRowNum();
			for(int i=1;i<=totalRows;i++) {
				Row row=sheet.getRow(i);
				TransactionDetails tx=new TransactionDetails();
				tx.setExtTranasactionId(row.getCell(0).getStringCellValue());
				tx.setClientId(row.getCell(1).getStringCellValue());
				tx.setSecurityId(row.getCell(2).getStringCellValue());
				tx.setTransactionType(row.getCell(3).getStringCellValue());
				tx.setTransactionDate(row.getCell(4).getDateCellValue());
				tx.setMarketValue(row.getCell(5).getNumericCellValue());
				tx.setPriority(row.getCell(6).getStringCellValue());
				transactions.add(tx);
			}
			
		} catch (IOException io) {
			io.printStackTrace();
			throw io;
		}
		return transactions;
		
	}

}
