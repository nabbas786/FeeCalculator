package com.nad.reader;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import com.nad.model.TransactionDetails;

public interface DataReader {

	List<TransactionDetails> readData(String filePath) throws IOException, ParseException;
}
