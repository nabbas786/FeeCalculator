package com.nad;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import com.nad.model.TransactionDetails;
import com.nad.reader.DataReader;
import com.nad.reader.DataReaderFactory;
import com.nad.service.TransactionService;

public class App {
	public static void main(String[] args) {
		try {
			if (args.length != 0 && args.length == 1) {
				String filePath = args[0];
				String type = filePath.substring(filePath.lastIndexOf('.') + 1);
				DataReader dataReader = DataReaderFactory.getDataReader(type);
				if(dataReader !=null) {
				List<TransactionDetails> transactions = dataReader.readData(filePath);
				TransactionService txService = new TransactionService();
				txService.setTransactions(transactions);
				txService.setDataReader(dataReader);
				txService.processTransactions(filePath);
				}else {
					System.out.println("Please run this application with argument as file absolute path");
				}
			} else {
				System.out.println("Accepted file formats are CSV and xlsx");
			}
		} catch (IOException | ParseException e) {
			
			if(e instanceof IOException) {
				System.err.println("Please run this application with valid file excepted file formats are excel and CSV");
			}
			if(e instanceof ParseException) {
				System.err.println("System is not able to parse the file please run this application with proper file");
			}
			e.printStackTrace();
		}
	}
	
}
