package com.nad.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.nad.model.TransactionDetails;
import com.nad.model.TransactionReport;
import com.nad.reader.DataReader;
import com.nad.reader.DataReaderFactory;

public class TransactionService {

	private List<TransactionDetails> transactions;
	private DataReader dataReader;

	public DataReader getDataReader() {
		return dataReader;
	}

	public void setDataReader(DataReader dataReader) {
		this.dataReader = dataReader;
	}

	public List<TransactionDetails> getTransactions() {
		return transactions;
	}

	public void setTransactions(List<TransactionDetails> transactions) {
		this.transactions = transactions;
	}

	public boolean processTransactions(String filePath) throws IOException, ParseException {

		if (filePath != null) {
			String type = filePath.substring(filePath.lastIndexOf('.') + 1);

			DataReader dataReader = DataReaderFactory.getDataReader(type);
			if (dataReader != null) {
				this.transactions = dataReader.readData(filePath);

				List<TransactionReport> transactionReports = new ArrayList<TransactionReport>();
				for (TransactionDetails tx : transactions) {
					TransactionReport txReport = new TransactionReport();
					txReport.setClientId(tx.getClientId());
					txReport.setPriority(tx.getPriority());
					txReport.setProcessingFee(this.calculateProcessingFee(tx));
					txReport.setTransactionType(tx.getTransactionType());
					txReport.setTransactionDate(tx.getTransactionDate());
					transactionReports.add(txReport);
				}

				if (transactionReports.size() > 0) {
					createTransactionReport(transactionReports);
					System.out.println("Transaction reports generated report generated ");
					return true;
				}
			} else {
				System.out.println("Accepted file formats are CSV and xlsx");
				return false;
			}
		}
		return false;
	}

	private double calculateProcessingFee(TransactionDetails tx) {
		double processingFee = 0;
		if (isIntraDayTransaction(tx, transactions)) {
			processingFee += 10;
		}
		if (tx.getPriority().equals("Y")) {
			processingFee += 500;
		} else {
			if (tx.getTransactionType().equalsIgnoreCase("Sell")
					|| tx.getTransactionType().equalsIgnoreCase("Withdraw")) {
				processingFee += 100;
			}
			if (tx.getTransactionType().equalsIgnoreCase("Buy")
					|| tx.getTransactionType().equalsIgnoreCase("Deposit")) {
				processingFee += 50;
			}
		}
		return processingFee;
	}

	private boolean isIntraDayTransaction(TransactionDetails tx, List<TransactionDetails> txDetails) {

		return txDetails.stream()
				.anyMatch(t -> ((t.getClientId().equalsIgnoreCase(tx.getClientId()))
						&& (t.getSecurityId().equalsIgnoreCase(tx.getSecurityId()))
						&& (tx.getTransactionDate().equals(t.getTransactionDate()))
						&& !(t.getTransactionType().equalsIgnoreCase(tx.getTransactionType()))));

	}

	private void createTransactionReport(List<TransactionReport> txReport) throws IOException {
		XSSFWorkbook workBook = new XSSFWorkbook();
		CreationHelper createHelper = workBook.getCreationHelper();
		Sheet sheet = workBook.createSheet("transaction_report");
		Row header = sheet.createRow(0);
		header.createCell(0).setCellValue("CLIENT ID");
		header.createCell(1).setCellValue("TRANSACTION type");
		header.createCell(2).setCellValue("TRANSACTION DATE");
		header.createCell(3).setCellValue("PRIORITY");
		header.createCell(4).setCellValue("PROCESSING FEE");

		for (int i = 1; i <= txReport.size(); i++) {
			TransactionReport tx = txReport.get(i - 1);
			Row row = sheet.createRow(i);
			row.createCell(0).setCellValue(tx.getClientId());
			row.createCell(1).setCellValue(tx.getTransactionType());
			Cell txDate = row.createCell(2);
			txDate.setCellValue(tx.getTransactionDate());
			CellStyle cellStyle = workBook.createCellStyle();
			cellStyle.setDataFormat(createHelper.createDataFormat().getFormat("MM/DD/YYYY"));
			txDate.setCellStyle(cellStyle);
			row.createCell(3).setCellValue(tx.getPriority());
			row.createCell(4).setCellValue(tx.getProcessingFee());
		}
		FileOutputStream out = new FileOutputStream(new File("TransactionReport.xlsx"));
		workBook.write(out);
		workBook.close();
		out.close();
	}
}
