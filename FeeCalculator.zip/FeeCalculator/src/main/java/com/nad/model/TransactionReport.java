package com.nad.model;

import java.util.Date;

public class TransactionReport {

	private String clientId;
	private String transactionType;
	private Date transactionDate;
	private String priority;
	private double processingFee;
	public TransactionReport() {
		super();
		// TODO Auto-generated constructor stub
	}
	public TransactionReport(String clientId, String transactionType, Date transactionDate, String priority,
			double processingFee) {
		super();
		this.clientId = clientId;
		this.transactionType = transactionType;
		this.transactionDate = transactionDate;
		this.priority = priority;
		this.processingFee = processingFee;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public Date getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public double getProcessingFee() {
		return processingFee;
	}
	public void setProcessingFee(double processingFee) {
		this.processingFee = processingFee;
	}
	@Override
	public String toString() {
		return "TransactionReport [clientId=" + clientId + ", transactionType=" + transactionType + ", transactionDate="
				+ transactionDate + ", priority=" + priority + ", processingFee=" + processingFee + "]";
	}
	
	
	
}
