package com.nad.model;

import java.util.Date;

public class TransactionDetails {

	private String extTranasactionId;
	private String clientId;
	private String securityId;
	private String transactionType;
	private Date transactionDate;
	private double marketValue;
	private String priority;

	public TransactionDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public TransactionDetails(String extTranasactionId, String clientId, String securityId, String transactionType,
			Date transactionDate, double marketValue, String priority) {
		super();
		this.extTranasactionId = extTranasactionId;
		this.clientId = clientId;
		this.securityId = securityId;
		this.transactionType = transactionType;
		this.transactionDate = transactionDate;
		this.marketValue = marketValue;
		this.priority = priority;
	}

	public String getExtTranasactionId() {
		return extTranasactionId;
	}

	public void setExtTranasactionId(String extTranasactionId) {
		this.extTranasactionId = extTranasactionId;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getSecurityId() {
		return securityId;
	}

	public void setSecurityId(String securityId) {
		this.securityId = securityId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	public double getMarketValue() {
		return marketValue;
	}

	public void setMarketValue(double marketValue) {
		this.marketValue = marketValue;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	@Override
	public String toString() {
		return "TransactionDetails [extTranasactionId=" + extTranasactionId + ", clientId=" + clientId + ", securityId="
				+ securityId + ", transactionType=" + transactionType + ", transactionDate=" + transactionDate
				+ ", marketValue=" + marketValue + ", priority=" + priority + "]";
	}

	
	
	
	
	
	
}
