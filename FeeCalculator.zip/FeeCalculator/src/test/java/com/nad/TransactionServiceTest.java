package com.nad;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.text.ParseException;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.nad.service.TransactionService;

public class TransactionServiceTest {

	private TransactionService txService;
	private String filePathForExcel;
	private String filePathForCSV;
	private String filePathForIO;
	private String filePathForNotParsable;
	
	@Before
	public void setup() {
		// creating fixture data
		 filePathForExcel="./testData/Sample_Data_new.xlsx";
		 filePathForCSV="./testData/Sample_Data_new_csv.csv";
		 filePathForIO="./testData";
		 filePathForNotParsable="./testData/Sample_Data_new2.xlsx";
		txService=new TransactionService();
	}
	
	@Test
	public void testcase_for_processing_excel_file() throws IOException, ParseException {
		boolean result=txService.processTransactions(filePathForExcel);
		assertTrue(result);
	}
	
	@Test
	public void testcase_for_processing_csv_file() throws IOException, ParseException {
		boolean result=txService.processTransactions(filePathForCSV);
		assertTrue(result);
	}
	
	@Test
	public void test_when_file_is_not_avaialble() throws IOException, ParseException {
		boolean result=txService.processTransactions(filePathForIO);
		assertFalse(result);
	}
	
	@After
	public void teardown() {
		 filePathForExcel=null;
		 filePathForCSV=null;
		 filePathForIO=null;
		 filePathForNotParsable=null;
		txService=null;
	}
	
}
