package com.nad;

import org.junit.Before;
import org.junit.Test;

public class DataReaderTest {

	@Before
	private void setup() {
		
	}
	@Test
	public void testExcelDataReader_if_file_is_available() {
		
	}
}
